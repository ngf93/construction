/* current year */
let now_year = new Date().getFullYear();
if(document.getElementById('year')){
    document.getElementById('year').innerHTML = now_year
}